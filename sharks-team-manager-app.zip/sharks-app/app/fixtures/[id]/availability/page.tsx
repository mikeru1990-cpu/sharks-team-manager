"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";
import type { Availability, Fixture, Player } from "@/lib/types";

const statuses: Availability["status"][] = ["available", "unavailable", "unknown"];

export default function AvailabilityPage({ params }: { params: { id: string } }) {
  const fixtureId = params.id;
  const [fixture, setFixture] = useState<Fixture | null>(null);
  const [players, setPlayers] = useState<Player[]>([]);
  const [availability, setAvailability] = useState<Record<string, Availability["status"]>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      const [fixtureRes, playersRes, availabilityRes] = await Promise.all([
        supabase.from("fixtures").select("*").eq("id", fixtureId).single(),
        supabase.from("players").select("*").eq("active", true).order("name"),
        supabase.from("availability").select("*").eq("fixture_id", fixtureId)
      ]);

      if (fixtureRes.error || playersRes.error || availabilityRes.error) {
        setError(fixtureRes.error?.message || playersRes.error?.message || availabilityRes.error?.message || "Could not load availability");
      } else {
        setFixture(fixtureRes.data as Fixture);
        const playerRows = (playersRes.data || []) as Player[];
        setPlayers(playerRows);
        const next: Record<string, Availability["status"]> = {};
        playerRows.forEach((player) => {
          next[player.id] = "unknown";
        });
        ((availabilityRes.data || []) as Availability[]).forEach((row) => {
          next[row.player_id] = row.status;
        });
        setAvailability(next);
      }

      setLoading(false);
    }

    loadData();
  }, [fixtureId]);

  const availableCount = useMemo(
    () => Object.values(availability).filter((status) => status === "available").length,
    [availability]
  );

  function setStatus(playerId: string, status: Availability["status"]) {
    setAvailability((current) => ({ ...current, [playerId]: status }));
  }

  async function saveAvailability() {
    setSaving(true);
    setMessage(null);
    setError(null);

    const rows = players.map((player) => ({
      fixture_id: fixtureId,
      player_id: player.id,
      status: availability[player.id] || "unknown"
    }));

    const { error } = await supabase.from("availability").upsert(rows, { onConflict: "fixture_id,player_id" });
    setSaving(false);

    if (error) {
      setError(error.message);
      return;
    }

    setMessage("Availability saved.");
  }

  return (
    <div className="grid">
      <section className="card space-between">
        <div>
          <p className="eyebrow">Availability</p>
          <h2 className="page-title">{fixture ? `vs ${fixture.opponent}` : "Match"}</h2>
          <p className="subtle">Mark each player as available, unavailable, or unknown.</p>
        </div>
        <div className="kpi"><strong>{availableCount}</strong><span>Available now</span></div>
      </section>

      <section className="card">
        {loading ? <p>Loading availability…</p> : error ? <p>{error}</p> : (
          <div className="list">
            {players.map((player) => (
              <div key={player.id} className="list-item space-between">
                <div>
                  <strong>{player.name}</strong>
                  <div className="row" style={{ marginTop: 8 }}>
                    {player.is_goalkeeper && <span className="badge blue">GK</span>}
                    {player.can_cover_goal && <span className="badge orange">GK cover</span>}
                  </div>
                </div>
                <div className="status-toggle">
                  {statuses.map((status) => (
                    <button
                      type="button"
                      key={status}
                      onClick={() => setStatus(player.id, status)}
                      className={availability[player.id] === status ? `status-pill active ${status}` : "status-pill"}
                    >
                      {status}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="card row">
        <button className="button" onClick={saveAvailability} disabled={saving || loading}>{saving ? "Saving…" : "Save availability"}</button>
        <Link href={`/fixtures/${fixtureId}/plan`} className="button-secondary">Go to plan</Link>
        {message && <span className="badge green">{message}</span>}
      </section>
    </div>
  );
}
