"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

export default function NewFixturePage() {
  const router = useRouter();
  const [opponent, setOpponent] = useState("");
  const [matchDate, setMatchDate] = useState("");
  const [venue, setVenue] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    setSaving(true);
    setError(null);

    const { data, error } = await supabase
      .from("fixtures")
      .insert({ opponent, match_date: matchDate, venue: venue || null, notes: notes || null })
      .select()
      .single();

    setSaving(false);

    if (error) {
      setError(error.message);
      return;
    }

    router.push(`/fixtures/${data.id}`);
  }

  return (
    <div className="grid">
      <section className="card stack">
        <p className="eyebrow">Setup</p>
        <h2 className="page-title">Create fixture</h2>
        <p className="subtle">Add the match first, then go straight into availability.</p>
      </section>

      <form className="card stack" onSubmit={handleSubmit}>
        <div>
          <label className="label">Opponent</label>
          <input className="input" value={opponent} onChange={(e) => setOpponent(e.target.value)} required />
        </div>
        <div>
          <label className="label">Match date</label>
          <input className="input" type="date" value={matchDate} onChange={(e) => setMatchDate(e.target.value)} required />
        </div>
        <div>
          <label className="label">Venue</label>
          <input className="input" value={venue} onChange={(e) => setVenue(e.target.value)} placeholder="Home / Away / address" />
        </div>
        <div>
          <label className="label">Notes</label>
          <textarea className="textarea" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Extra notes for the match" />
        </div>

        {error && <p>{error}</p>}

        <div className="row">
          <button className="button" disabled={saving} type="submit">{saving ? "Saving…" : "Create fixture"}</button>
        </div>
      </form>
    </div>
  );
}
