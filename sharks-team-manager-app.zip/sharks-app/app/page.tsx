"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import type { Fixture, Player } from "@/lib/types";

export default function HomePage() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [fixtures, setFixtures] = useState<Fixture[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      setError(null);

      const [playersRes, fixturesRes] = await Promise.all([
        supabase.from("players").select("*").eq("active", true).order("name"),
        supabase.from("fixtures").select("*").order("match_date", { ascending: true }).limit(5)
      ]);

      if (playersRes.error || fixturesRes.error) {
        setError(playersRes.error?.message || fixturesRes.error?.message || "Could not load dashboard");
      } else {
        setPlayers((playersRes.data || []) as Player[]);
        setFixtures((fixturesRes.data || []) as Fixture[]);
      }

      setLoading(false);
    }

    loadData();
  }, []);

  return (
    <div className="grid">
      <section className="card stack">
        <p className="eyebrow">Coach Dashboard</p>
        <h2 className="page-title">Sharks Team Manager</h2>
        <p className="subtle">Pick the weekly 10, manage availability, and generate quarter plans in a few taps.</p>
        <div className="row">
          <Link href="/fixtures/new" className="button">Create fixture</Link>
          <Link href="/fixtures" className="button-secondary">Open fixtures</Link>
        </div>
      </section>

      {loading ? (
        <section className="card"><p>Loading dashboard…</p></section>
      ) : error ? (
        <section className="card"><p>{error}</p></section>
      ) : (
        <>
          <section className="card grid three">
            <div className="kpi"><strong>{players.length}</strong><span>Active players</span></div>
            <div className="kpi"><strong>{players.filter((p) => p.is_goalkeeper).length}</strong><span>Goalkeepers</span></div>
            <div className="kpi"><strong>{fixtures.length}</strong><span>Upcoming fixtures shown</span></div>
          </section>

          <section className="card">
            <div className="space-between">
              <div>
                <p className="eyebrow">Next matches</p>
                <h3>Fixtures</h3>
              </div>
              <Link href="/fixtures" className="button-secondary">All fixtures</Link>
            </div>
            {fixtures.length === 0 ? (
              <div className="empty">No fixtures yet. Create your first one.</div>
            ) : (
              <div className="list">
                {fixtures.map((fixture) => (
                  <div key={fixture.id} className="list-item space-between">
                    <div>
                      <strong>{fixture.opponent}</strong>
                      <p className="helper">{fixture.match_date} {fixture.venue ? `• ${fixture.venue}` : ""}</p>
                    </div>
                    <div className="row">
                      <Link href={`/fixtures/${fixture.id}/availability`} className="button-secondary">Availability</Link>
                      <Link href={`/fixtures/${fixture.id}/plan`} className="button">Plan</Link>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
}
