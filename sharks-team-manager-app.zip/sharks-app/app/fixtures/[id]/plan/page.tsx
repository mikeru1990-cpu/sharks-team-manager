"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";
import type { Fixture, MatchPlanRow } from "@/lib/types";

function displayRole(value: string | null) {
  if (value === "OUTFIELD") return "Play";
  if (value === "BENCH") return "Bench";
  return value || "—";
}

export default function PlanPage({ params }: { params: { id: string } }) {
  const fixtureId = params.id;
  const [fixture, setFixture] = useState<Fixture | null>(null);
  const [rows, setRows] = useState<MatchPlanRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadFixture() {
      const { data, error } = await supabase.from("fixtures").select("*").eq("id", fixtureId).single();
      if (error) setError(error.message);
      else setFixture(data as Fixture);
      setLoading(false);
    }
    loadFixture();
  }, [fixtureId]);

  async function generatePlan() {
    setGenerating(true);
    setError(null);
    const { data, error } = await supabase.rpc("generate_match_plan", { p_fixture_id: fixtureId });
    setGenerating(false);

    if (error) {
      setError(error.message);
      return;
    }

    setRows((data || []) as MatchPlanRow[]);
  }

  const selectedRows = useMemo(() => rows.filter((row) => row.selection_status === "selected"), [rows]);
  const reserveRows = useMemo(() => rows.filter((row) => row.selection_status === "reserve"), [rows]);
  const unavailableRows = useMemo(() => rows.filter((row) => row.selection_status === "not_available"), [rows]);

  return (
    <div className="grid">
      <section className="card space-between">
        <div>
          <p className="eyebrow">Match plan</p>
          <h2 className="page-title">{fixture ? `vs ${fixture.opponent}` : "Generate squad"}</h2>
          <p className="subtle">Run the auto-picker after you have saved availability.</p>
        </div>
        <div className="row">
          <Link href={`/fixtures/${fixtureId}/availability`} className="button-secondary">Availability</Link>
          <button className="button" disabled={generating || loading} onClick={generatePlan}>
            {generating ? "Generating…" : "Generate squad"}
          </button>
        </div>
      </section>

      {error && <section className="card"><p>{error}</p></section>}

      {rows.length > 0 && (
        <>
          <section className="card grid three">
            <div className="kpi"><strong>{selectedRows.length}</strong><span>Selected</span></div>
            <div className="kpi"><strong>{reserveRows.length}</strong><span>Reserves</span></div>
            <div className="kpi"><strong>{unavailableRows.length}</strong><span>Unavailable</span></div>
          </section>

          <section className="card">
            <h3>Selected squad</h3>
            <div className="list">
              {selectedRows.map((row) => (
                <div key={row.player_name} className="list-item space-between">
                  <strong>{row.player_name}</strong>
                  <span className="badge green">Selected</span>
                </div>
              ))}
            </div>
          </section>

          <section className="card">
            <h3>Quarter plan</h3>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Player</th>
                    <th>Q1</th>
                    <th>Q2</th>
                    <th>Q3</th>
                    <th>Q4</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedRows.map((row) => (
                    <tr key={row.player_name}>
                      <td>{row.player_name}</td>
                      <td>{displayRole(row.q1)}</td>
                      <td>{displayRole(row.q2)}</td>
                      <td>{displayRole(row.q3)}</td>
                      <td>{displayRole(row.q4)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {reserveRows.length > 0 && (
            <section className="card">
              <h3>Reserves</h3>
              <div className="list">
                {reserveRows.map((row) => (
                  <div key={row.player_name} className="list-item space-between">
                    <strong>{row.player_name}</strong>
                    <span className="badge orange">Reserve</span>
                  </div>
                ))}
              </div>
            </section>
          )}
        </>
      )}
    </div>
  );
}
