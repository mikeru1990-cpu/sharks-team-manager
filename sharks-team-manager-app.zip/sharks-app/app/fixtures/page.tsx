"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import type { Fixture } from "@/lib/types";

export default function FixturesPage() {
  const [fixtures, setFixtures] = useState<Fixture[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadFixtures() {
      const { data, error } = await supabase.from("fixtures").select("*").order("match_date", { ascending: true });
      if (error) {
        setError(error.message);
      } else {
        setFixtures((data || []) as Fixture[]);
      }
      setLoading(false);
    }
    loadFixtures();
  }, []);

  return (
    <div className="grid">
      <section className="card space-between">
        <div>
          <p className="eyebrow">Schedule</p>
          <h2 className="page-title">Fixtures</h2>
          <p className="subtle">Create a fixture, set availability, then generate the match plan.</p>
        </div>
        <Link href="/fixtures/new" className="button">New fixture</Link>
      </section>

      <section className="card">
        {loading ? <p>Loading fixtures…</p> : error ? <p>{error}</p> : fixtures.length === 0 ? (
          <div className="empty">No fixtures yet.</div>
        ) : (
          <div className="list">
            {fixtures.map((fixture) => (
              <div key={fixture.id} className="list-item">
                <div className="space-between">
                  <div>
                    <strong>{fixture.opponent}</strong>
                    <p className="helper">{fixture.match_date} {fixture.venue ? `• ${fixture.venue}` : ""}</p>
                    {fixture.notes && <p className="helper">{fixture.notes}</p>}
                  </div>
                  <Link href={`/fixtures/${fixture.id}`} className="button-secondary">Open</Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
